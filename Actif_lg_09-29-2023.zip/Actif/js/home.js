function parse_main_feed() {
    setTimeout(function () {
        $("#loader").show();
        getCategories();
        manage_spatial_navigation("menu_container");
        navigation_func();
        $("#menu_1").addClass("selected_menu");
        $(".menu_container").addClass("minimize-sidebar");
    }, 500);
}

function navigation_func() {
    manage_spatial_navigation("category_container");
    manage_spatial_navigation("home_video_list");
    manage_spatial_navigation("dashboard_container");
    manage_spatial_navigation("subcategory_container");
    manage_spatial_navigation("video_list_container");
    manage_spatial_navigation("language_container");
    manage_spatial_navigation("keyboard_container");
    manage_spatial_navigation("category_selection");
    manage_spatial_navigation("subcategory_selection");
    manage_spatial_navigation("intensity_selection");
    manage_spatial_navigation("duration_selection");
    manage_spatial_navigation("filter_keys");
    manage_spatial_navigation("subcategory_filter_options");
    manage_spatial_navigation("intensity_filter_options");
    manage_spatial_navigation("duration_filter_options");
    manage_spatial_navigation("search_result_container");
}

function hide_show_screens(className) {
    $("#loader").show();
    $("#video_player_about_video").hide();
    if (className == 'video_container') {
        $(".video-player-container").show();
        $(".main-container").hide();
    } else $(".main-container").show();

    $(".search_container, .home_container, .dashboard_container, .subcategory_container, .video_list_container, .setting_container, .video_container, .modal_container").removeClass("active").hide();

    if (className != '') {
        $("." + className).addClass("active").show();
        $("#loader").hide();
    }
}


function request_search_results() {
    searchText = get_searched_text();
    if (searchText != "") getFilteredVideo();
    else {
        $('#searchInputText').attr("placeholder", "Please enter text here");
        $('#searchInputText').val("");
        SN.focus('keyboard');
    }
}

function get_searched_text() {
    return $.trim($('#searchInputText').val());
}

function setCategoryFilterOptions() {
    console.log("setFilterOptions");
    var id = '',
        str = '',
        upFocus = '',
        downFocus = '',
        leftFocus = '',
        rightFocus = '';
    var total = APP_CATEGORY_ARRAY.length;

    str += ' <ul class="filter-options-list" id="category_options">';
    for (var i = 0; i < total; i++) {
        id = 'id="cat_option_' + i + '" ';

        if (i < 2) upFocus = 'data-sn-up="null"';
        else upFocus = 'data-sn-up="#cat_option_' + (i - 2) + '" ';

        if (i > (total - 2)) downFocus = 'data-sn-down="null"';
        else downFocus = 'data-sn-down="#cat_option_' + (i + 2) + '" ';

        if (i == (total - 1)) rightFocus = 'data-sn-right="null" ';
        else rightFocus = 'data-sn-right="#cat_option_' + (i + 1) + '" ';

        if (i == 0 || (i % 2 == 0)) leftFocus = 'data-sn-left="null" ';
        else leftFocus = 'data-sn-left="#cat_option_' + (i - 1) + '" ';

        str += '<li class="filter-category-list focusable"  tabindex="18" ' + id + upFocus + downFocus + rightFocus + leftFocus + ' data-id="' + APP_CATEGORY_ARRAY[i]["_id"] + '"><div><img src="images/filter-unchecked.png"><h4>' + APP_CATEGORY_ARRAY[i]["name"] + '</h4></div></li>';
    }
    str += '</ul>';

    $(".category_filter_options").html(str);
    manage_spatial_navigation("category_filter_options");
    addEventListeners();
}


function setSearchRecommendedVideos(flag) {
    var total = 0, heading = "", data = [];
    if (flag) {
        total = APP_SEARCH_ARRAY.getVideos.length;
        data = APP_SEARCH_ARRAY.getVideos;
        if (APP_SEARCH_ARRAY.hasMetadata.nextPage == 2) $("#search_result").html(""); //page = APP_SEARCH_ARRAY.hasMetadata.nextPage;
        heading = "Result(" + APP_SEARCH_ARRAY.hasMetadata.totalVideos + ")";
    } else {
        total = APP_SEARCH_ARRAY.length;
        data = APP_SEARCH_ARRAY;
        heading = "Recommended(" + total + ")";
    }

    if (data.length < 1) heading = "Result (0)";

    if (total > 0) {
        var id = '',
            str = '',
            upFocus = '',
            downFocus = '',
            leftFocus = '',
            rightFocus = '';

        $(".search-result-heading").text(heading);
        var j = $("#search_result li").length;

        for (var i = 0; i < data.length; i++) {
            id = 'id="search_' + j + '" ';

            if (j < 2) upFocus = 'data-sn-up="null"';
            else upFocus = '';
            // else upFocus = 'data-sn-up="#search_' + (j - 2) + '" ';

            // if (j > (total - 2)) downFocus = 'data-sn-down="null"';
            // downFocus = 'data-sn-down="#search_' + (j + 2) + '" ';

            // if (i == (total - 1)) rightFocus = 'data-sn-right="null" ';
            rightFocus = 'data-sn-right="#search_' + (i + 1) + '" ';

            // if (i == 0 || (i % 2 == 0)) leftFocus = 'data-sn-left="null" ';
            // else leftFocus = 'data-sn-left="#search_' + (i - 1) + '" ';

            str += '<li class="focusable"  tabindex="21" ' + id + upFocus + downFocus + rightFocus + leftFocus + '><div class="inner-thumbnail"><img src="' + data[i]["thumbnail"] + '"><div class="inner-thumbnail-details">';
            str += '<h6>' + data[i]["title"] + '</h6><span class="badge  badge1">' + data[i]["categoryId"]["name"] + '</span><div class="duration"><img src="images/clock.png"><span>' + data[i]["duration"] + ' Minutes </span></div>';
            str += '</div></div></li>';

            j++;
        }

        $("#search_result").append(str);
        addEventListeners();

    } else $("#search_list").html('<div class="search-not-found">No videos found.<div>');
}

function resuffleSubcategoryOptions(categoryId) {
    console.log("resuffleSubcategoryOptions", categoryId);
    if ($("#subcategory_options li").length < 1) {
        $("#subcategory_filter").find(".main-filter-heading").text("Subcatgeory");
        $(".filter-conatiner-list").children(":nth-child(2)").addClass("list-disabled");
        return;
    }

    var id = '',
        str = '',
        upFocus = '',
        downFocus = '',
        leftFocus = '',
        rightFocus = '';

    var j = 0;

    $("#subcategory_options li").each(function (i) {
        if ($(this).attr("data-cat") != categoryId) {
            id = 'id="search_' + j + '" ';

            if (j < 2) upFocus = 'data-sn-up="null"';
            else upFocus = '';
            // else upFocus = 'data-sn-up="#search_' + (j - 2) + '" ';

            // if (j > (total - 2)) downFocus = 'data-sn-down="null"';
            // downFocus = 'data-sn-down="#search_' + (j + 2) + '" ';

            // if (i == (total - 1)) rightFocus = 'data-sn-right="null" ';
            rightFocus = 'data-sn-right="#search_' + (j + 1) + '" ';

            // if (i == 0 || (i % 2 == 0)) leftFocus = 'data-sn-left="null" ';
            // else leftFocus = 'data-sn-left="#search_' + (i - 1) + '" ';
            if ($(this).hasClass("selected_option")) {
                img = "images/filter-checked.png";
                selectedClass = " selected_option ";
            } else {
                img = "images/filter-unchecked.png";
                selectedClass = "";
            }

            str += '<li class="filter-subcategory-list focusable' + selectedClass + ' "  tabindex="19" data-cat="' + categoryId + '" data-id="' + $(this).attr("data-id") + '" ' + id + upFocus + downFocus + rightFocus + leftFocus + '><div><img src="' + img + '"><h4>' + $(this).find("h4").text() + '</h4></div></li>';

            j++;
        }
    });
    $("#subcategory_options").html(str);

    if ($("#subcategory_options li").length < 1) {
        $("#subcategory_filter").find(".main-filter-heading").text("Subcatgeory");
        $(".filter-conatiner-list").children(":nth-child(2)").addClass("list-disabled");
    } else if ($("#subcategory_options li").length > 0) {
        $("#subcategory_filter").find(".main-filter-heading").text("Subcatgeory" + "(" + $("#subcategory_options li.selected_option").length + ")");
        $(".filter-conatiner-list").children(":nth-child(2)").removeClass("list-disabled");
    }
}

function set_video_details() {
    var i, data = [], cls = '', intensity = "";
    console.log(PAGE_INDEX);
    if (PAGE_INDEX == 0) {
        data = APP_SEARCH_ARRAY;
        i = $("#" + FIRST_LEVEL_SELECTED_ITEM).index();
    } else if (PAGE_INDEX == 1) {
        data = APP_DATA_ARRAY;
        i = $("#" + FIRST_LEVEL_SELECTED_ITEM).parent().index();
    } else if (PAGE_INDEX == 5) {
        data = APP_VIDEO_ARRAY;
        i = $("#" + THIRD_LEVEL_SELECTED_ITEM).parent().index();
    }
    console.log(data, data[i]["class"]);
    cls = "intensity-color-" + data[i]["class"];
    if (data[i]["class"] == 'high') intensity = "Orange Intensity";
    else if (data[i]["class"] == 'low') intensity = "Blue Intensity";
    else if (data[i]["class"] == 'mid') intensity = "Purple Intensity";

    $("#videoTitle").text(data[i]["title"]);
    $("#videoDesc").text(data[i]["description"]);
    $("#videoDuration").text(data[i]["duration"] + " Minutes");
    $("#videoCategory").text(data[i]["categoryId"]["name"]);
    $("#videoIntensity").html('<span class="color-circle ' + cls + '"></span><h4>' + intensity + '</h4> ');
}

function convertDate(startDate) {
    console.log(startDate);
    var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var d = new Date(startDate);
    var day = weekday[d.getDay()];
    var month = monthNames[d.getMonth()];
    var date = d.getDate();
    date = date + (31 == date || 21 == date || 1 == date ? "st" : 22 == date || 2 == date ? "nd" : 23 == date || 3 == date ? "rd" : "th")

    return day + ', ' + date + ' ' + month + ' ' + d.getFullYear();
}

function extractTimeInterval(start, end) {
    console.log(start, end)
    var st = new Date(start).toTimeString().replace(/.*(\d{2}:\d{2}):\d{2}.*/, "$1");
    var et = new Date(end).toTimeString().replace(/.*(\d{2}:\d{2}):\d{2}.*/, "$1");
    return st + " - " + et;
}

function deactivateFilterButtons() {
    if ($(".filter-conatiner-list .selected_option").length > 0) $("#filter_keys").css("opacity", "1");
    else $("#filter_keys").css("opacity", "0.5");
}
